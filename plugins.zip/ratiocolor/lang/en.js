
 
 theUILang.ratiocolorName = "Ratiocolor";
 theUILang.ratiocolorLengthError = "Ratiocolor: There must be the same numbers of levels and colors";
 theUILang.ratiocolorLevel0 = "Ratiocolor: The first level must be 0";
 theUILang.ratiocolorLegend = "Ratiocolor";
 theUILang.ratiocolorSettings = "Ratiocolor";
 
 thePlugins.get("ratiocolor").langLoaded();